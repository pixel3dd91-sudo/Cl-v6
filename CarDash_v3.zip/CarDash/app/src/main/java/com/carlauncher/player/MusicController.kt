package com.carlauncher.player

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder

/** کنترل پخش: موزیک داخلی یا هر پلیر دیگر (Spotify و ...) */
class MusicController(private val act: Activity, private val onChange: () -> Unit) {

    var svc: PlayerService? = null
        private set
    val ext = ExternalMedia(act) { onChange() }
    var useExt = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            val s = (b as PlayerService.LocalBinder).service
            svc = s
            s.listener = { onChange() }
            loadIfPermitted()
            onChange()
        }
        override fun onServiceDisconnected(n: ComponentName) { svc = null }
    }

    fun audioPerm(): String =
        if (Build.VERSION.SDK_INT >= 33 && act.applicationInfo.targetSdkVersion >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun granted(): Boolean =
        Build.VERSION.SDK_INT < 23 || act.checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED

    fun start() {
        val i = Intent(act, PlayerService::class.java)
        if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i) else act.startService(i)
        act.bindService(i, conn, Context.BIND_AUTO_CREATE)
        ext.start()
    }

    fun stop() {
        ext.stop()
        try { act.unbindService(conn) } catch (_: Exception) {}
    }

    fun loadIfPermitted() {
        val s = svc ?: return
        if (!granted()) return
        if (s.allTracks.isEmpty()) s.loadTracks()
        if (Prefs.get(act).autoResume && s.allTracks.isNotEmpty() && !s.resumeDone && !useExt) s.resumeLast()
    }

    fun decide() {
        val extPlaying = ext.isPlaying
        val locPlaying = svc?.isPlaying == true
        if (extPlaying) useExt = true
        else if (locPlaying) useExt = false
        else if (useExt && ext.active == null) useExt = false
    }

    val title: String
        get() = if (useExt) (ext.title ?: "—") else (svc?.currentTrack?.title ?: "موزیکی پخش نمی‌شود")

    val artist: String
        get() = if (useExt) (ext.artist ?: "") else (svc?.currentTrack?.artist ?: "")

    val playing: Boolean
        get() = if (useExt) ext.isPlaying else (svc?.isPlaying == true)

    val pos: Int
        get() = if (useExt) ext.position else (svc?.position ?: 0)

    val dur: Int
        get() = if (useExt) ext.duration else (svc?.duration ?: 0)

    fun toggle() {
        if (useExt) {
            val tc = ext.active?.transportControls ?: return
            if (ext.isPlaying) tc.pause() else tc.play()
        } else {
            svc?.toggle()
        }
    }

    fun next() { if (useExt) ext.active?.transportControls?.skipToNext() else svc?.next() }
    fun prev() { if (useExt) ext.active?.transportControls?.skipToPrevious() else svc?.prev() }

    fun seek(f: Float) {
        if (useExt) {
            val d = ext.duration
            if (d > 0) ext.active?.transportControls?.seekTo((d * f).toLong())
        } else {
            val s = svc ?: return
            s.seekTo((f * s.duration).toInt())
        }
    }
}
