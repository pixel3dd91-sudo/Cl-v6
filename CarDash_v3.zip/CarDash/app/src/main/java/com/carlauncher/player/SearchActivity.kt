package com.carlauncher.player

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** جستجوی مقصد (Nominatim / OpenStreetMap) و مقصدهای اخیر */
class SearchActivity : Activity() {

    private val rows = ArrayList<Dest>()
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var prefs: Prefs
    private var curLat = 0.0
    private var curLon = 0.0
    private var accent = 0xFF2F7BFF.toInt()

    private val adapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(p: Int) = rows[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val v: LinearLayout
            if (cv is LinearLayout) {
                v = cv
            } else {
                v = LinearLayout(this@SearchActivity)
                v.orientation = LinearLayout.VERTICAL
                v.setPadding(u(16), u(12), u(16), u(12))
                v.background = rippleBg(0, 0, 0, false, u(10).toFloat())
                val t = label(21f, Color.WHITE)
                t.setSingleLine(true)
                t.ellipsize = TextUtils.TruncateAt.END
                val s = label(14f, 0x99FFFFFF.toInt())
                s.setSingleLine(true)
                s.ellipsize = TextUtils.TruncateAt.END
                v.addView(t, lp(MATCH, WRAP))
                v.addView(s, lp(MATCH, WRAP))
            }
            val d = rows[p]
            (v.getChildAt(0) as TextView).setFa(d.name, true)
            (v.getChildAt(1) as TextView).setFa(d.addr)
            return v
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs.get(this)
        curLat = intent.getDoubleExtra("lat", 0.0)
        curLon = intent.getDoubleExtra("lon", 0.0)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setBackgroundColor(Color.parseColor("#0F1117"))
        root.setPadding(u(26), u(14), u(26), u(12))

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "مقصد را بنویسید..."
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(0x66FFFFFF)
        input.setSingleLine(true)
        input.textSize = 20f
        input.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.setPadding(u(18), u(8), u(18), u(8))
        input.background = rippleBg(0x22FFFFFF, 0, 0, false, u(24).toFloat())
        input.setOnEditorActionListener { _, _, _ -> doSearch(); true }
        bar.addView(input, lp(0, u(52)).also { it.weight = 1f })

        val go = label(18f, Color.WHITE)
        go.setFa("جستجو", true)
        go.gravity = Gravity.CENTER
        go.setPadding(u(22), u(8), u(22), u(8))
        go.background = rippleBg(accent, 0, 0, false, u(24).toFloat())
        go.setOnClickListener { doSearch() }
        bar.addView(go, lp(WRAP, u(52)).also { it.leftMargin = u(10) })

        val close = label(30f, accent)
        close.text = "✕"
        close.gravity = Gravity.CENTER
        close.setPadding(u(18), u(6), u(14), u(6))
        close.setOnClickListener { finish() }
        bar.addView(close)
        root.addView(bar, lp(MATCH, u(60)))

        status = label(15f, 0x99FFFFFF.toInt())
        status.setFa("مقصدهای اخیر")
        root.addView(status, lp(MATCH, WRAP).also { it.topMargin = u(8); it.bottomMargin = u(4) })

        val list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ -> select(rows[pos]) }
        root.addView(list, lp(MATCH, 0).also { it.weight = 1f })
        setContentView(root)

        showRecents()
        input.requestFocus()
    }

    private fun recents(): List<Dest> {
        val out = ArrayList<Dest>()
        for (line in prefs.recents.split("\n")) {
            val f = line.split("|")
            if (f.size >= 4) {
                val la = f[2].toDoubleOrNull()
                val lo = f[3].toDoubleOrNull()
                if (la != null && lo != null) out.add(Dest(f[0], f[1], la, lo))
            }
        }
        return out
    }

    private fun saveRecent(d: Dest) {
        val clean = { s: String -> s.replace("|", " ").replace("\n", " ") }
        val list = ArrayList<Dest>()
        list.add(d)
        for (r in recents()) {
            if (list.size >= 8) break
            if (Math.abs(r.lat - d.lat) > 0.0002 || Math.abs(r.lon - d.lon) > 0.0002) list.add(r)
        }
        prefs.recents = list.joinToString("\n") {
            clean(it.name) + "|" + clean(it.addr) + "|" + it.lat + "|" + it.lon
        }
    }

    private fun showRecents() {
        rows.clear()
        rows.addAll(recents())
        status.setFa(if (rows.isEmpty()) "مقصدی ذخیره نشده است. نام یک مکان را جستجو کنید." else "مقصدهای اخیر")
        adapter.notifyDataSetChanged()
    }

    private fun doSearch() {
        val q = input.text.toString().trim()
        if (q.isEmpty()) {
            showRecents()
            return
        }
        status.setFa("در حال جستجو...")
        Thread {
            try {
                val res = Nav.search(q, curLat, curLon)
                runOnUiThread {
                    rows.clear()
                    rows.addAll(res)
                    status.setFa(if (res.isEmpty()) "نتیجه‌ای پیدا نشد." else "نتایج جستجو")
                    adapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                runOnUiThread { status.setFa("خطا در جستجو. اتصال اینترنت را بررسی کنید.") }
            }
        }.start()
    }

    private fun select(d: Dest) {
        saveRecent(d)
        val i = Intent()
        i.putExtra("name", d.name)
        i.putExtra("addr", d.addr)
        i.putExtra("lat", d.lat)
        i.putExtra("lon", d.lon)
        setResult(RESULT_OK, i)
        finish()
    }
}
