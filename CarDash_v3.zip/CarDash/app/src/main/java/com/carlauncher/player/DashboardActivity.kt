package com.carlauncher.player

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class DashboardActivity : Activity() {

    private class Tile(val box: LinearLayout, val circle: FrameLayout, val title: TextView, val sub: TextView) {
        var on: Boolean? = null
        var subText: String = ""
    }

    private lateinit var prefs: Prefs
    private lateinit var music: MusicController
    private lateinit var radios: Radios
    private lateinit var am: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private val blue = Color.parseColor("#2F7BFF")
    private val hotRed = Color.parseColor("#FF3B30")
    private val rootBase = Color.parseColor("#12141B")
    private val rootHot = Color.parseColor("#2B0A0F")
    private val cardBase = Color.parseColor("#1B1E29")
    private val cardHot = Color.parseColor("#2E161B")
    private var builtVersion = -1

    // ---- views ----
    private lateinit var root: FrameLayout
    private lateinit var sideBar: LinearLayout
    private lateinit var leftPanel: LinearLayout
    private lateinit var pager: SlidePager
    private lateinit var pageDots: PageDots
    private lateinit var carView: CarView
    private lateinit var gauge: GaugeView
    private lateinit var speedTv: TextView
    private lateinit var unitTv: TextView
    private lateinit var speedLabel: TextView
    private lateinit var btTile: Tile
    private lateinit var wifiTile: Tile
    private lateinit var tickBar: TickBar
    private lateinit var volPct: TextView
    private lateinit var statusDots: DotsView
    private lateinit var netTv: TextView
    private lateinit var btIcon: ImageView
    private lateinit var tempTv: TextView
    private lateinit var timeTv: TextView
    private lateinit var mapView: MapView
    private lateinit var mask: CornerMask
    private lateinit var attrTv: TextView
    private lateinit var sport: SportOverlay
    private lateinit var instrCard: LinearLayout
    private lateinit var instrArrow: ImageView
    private lateinit var instrDist: TextView
    private lateinit var instrText: TextView
    private lateinit var recenterBtn: ImageButton
    private lateinit var routeTitle: TextView
    private lateinit var routeAddr: TextView
    private lateinit var routeIcon: ImageView
    private lateinit var routeClose: TextView
    private lateinit var routeBar: RouteBar
    private lateinit var statsTv: TextView
    private lateinit var arrivalTv: TextView
    private lateinit var detailsTv: TextView
    private lateinit var musicTitle: TextView
    private lateinit var musicArtist: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var musicProgress: ProgressLine
    private lateinit var posTv: TextView
    private lateinit var remTv: TextView

    // ---- map / route state ----
    private lateinit var routeLine: Polyline
    private lateinit var carMarker: Marker
    private lateinit var destMarker: Marker
    private var destOnMap = false
    private var route: Route? = null
    private var tracker: RouteTracker? = null
    private var dest: Dest? = null
    private var follow = true
    private var firstFix = false
    private var orient = 0f
    private var lastReroute = 0L
    private var locationManager: LocationManager? = null
    private var lastLoc: Location? = null
    private var lastLocAt = 0L
    private var curKmh = 0f
    private var weatherAt = 0L
    private var askedPerms = false
    private var downX = 0f
    private var downY = 0f
    private var longRun: Runnable? = null

    // ---- sport effect ----
    private var sportT = 0f
    private var sportTarget = -1f
    private var sportAnim: ValueAnimator? = null

    private val locListener = object : LocationListener {
        override fun onLocationChanged(l: Location) { handleLocation(l) }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 450)
        }
    }

    // =====================================================================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs.get(this)
        am = getSystemService(AUDIO_SERVICE) as AudioManager
        radios = Radios(this)
        initOsmdroid()
        music = MusicController(this) { runOnUiThread { updateMusic() } }
        buildUi()
        applyPrefs()
        music.start()
        requestPerms()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        if (prefs.version != builtVersion) applyPrefs()
        music.ext.start()
        music.loadIfPermitted()
        startLocation()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        music.svc?.saveState()
        stopLocation()
        mapView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        music.stop()
        mapView.onDetach()
        super.onDestroy()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() { /* داشبورد بسته نمی‌شود */ }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_NEXT -> { music.next(); return true }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { music.prev(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK -> { music.toggle(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { if (!music.playing) music.toggle(); return true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { if (music.playing) music.toggle(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    // =====================================================================
    // ساخت رابط
    private fun initOsmdroid() {
        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, android.preference.PreferenceManager.getDefaultSharedPreferences(applicationContext))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osmdroid")
        cfg.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
    }

    private fun sideButton(res: Int, active: Boolean): ImageButton {
        val b = iconButton(res, 56, 14)
        b.setColorFilter(if (active) blue else 0xAAFFFFFF.toInt())
        return b
    }

    private fun makeTile(iconRes: Int, titleText: String): Tile {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(u(14), u(12), u(14), u(10))
        box.background = rippleBg(0xFF262A37.toInt(), 0, 0, false, u(18).toFloat())
        box.isClickable = true
        box.isFocusable = true
        val circle = FrameLayout(this)
        val icon = ImageView(this)
        icon.setImageResource(iconRes)
        circle.addView(icon, FrameLayout.LayoutParams(u(24), u(24), Gravity.CENTER))
        box.addView(circle, lp(u(42), u(42)))
        val t = label(17f, Color.WHITE)
        t.setFa(titleText, true)
        val s = label(13f, 0xFF8A90A0.toInt())
        s.setSingleLine(true)
        s.ellipsize = TextUtils.TruncateAt.END
        box.addView(t, lp(MATCH, WRAP).also { it.topMargin = u(8) })
        box.addView(s, lp(MATCH, WRAP))
        return Tile(box, circle, t, s)
    }

    private fun setTile(t: Tile, on: Boolean, sub: String) {
        if (t.on != on) {
            t.on = on
            val g = GradientDrawable()
            g.setShape(GradientDrawable.OVAL)
            g.setColor(if (on) blue else 0xFF3A3F52.toInt())
            t.circle.background = g
        }
        if (t.subText != sub) {
            t.subText = sub
            t.sub.setFa(sub)
        }
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setBackgroundColor(rootBase)

        val shell = LinearLayout(this)
        shell.orientation = LinearLayout.HORIZONTAL
        root.addView(shell, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---------- نوار کناری ----------
        sideBar = LinearLayout(this)
        sideBar.orientation = LinearLayout.VERTICAL
        sideBar.gravity = Gravity.CENTER_HORIZONTAL
        sideBar.setBackgroundColor(0xFF151821.toInt())
        sideBar.setPadding(0, u(24), 0, u(24))

        val navBtn = sideButton(R.drawable.ic_nav, true)
        navBtn.setOnClickListener { follow = true; recenter() }
        val appsBtn = sideButton(R.drawable.ic_apps, false)
        appsBtn.setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        val musicBtn = sideButton(R.drawable.ic_music, false)
        musicBtn.setOnClickListener { startActivity(Intent(this, PlayerActivity::class.java)) }
        val phoneBtn = sideButton(R.drawable.ic_phone, false)
        phoneBtn.setOnClickListener {
            val p = prefs.phonePkg
            if (p.isNotEmpty()) {
                val i = packageManager.getLaunchIntentForPackage(p)
                if (i != null) startActivity(i) else pickApp(201)
            } else {
                try { startActivity(Intent(Intent.ACTION_DIAL)) } catch (e: Exception) { pickApp(201) }
            }
        }
        phoneBtn.setOnLongClickListener { pickApp(201); true }
        val carBtn = sideButton(R.drawable.ic_car, false)
        carBtn.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        for (b in arrayOf(navBtn, appsBtn, musicBtn, phoneBtn, carBtn)) {
            sideBar.addView(b, lp(u(56), u(56)).also { it.topMargin = u(16); it.bottomMargin = u(16) })
        }
        shell.addView(sideBar, lp(u(84), MATCH))

        // ---------- ستون اصلی ----------
        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.setPadding(u(16), u(8), u(16), u(14))
        shell.addView(main, lp(0, MATCH).also { it.weight = 1f })

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        statusDots = DotsView(this)
        top.addView(statusDots, lp(u(46), u(12)))
        netTv = label(16f, 0xFFB8BDCC.toInt())
        top.addView(netTv, lp(WRAP, WRAP).also { it.leftMargin = u(10) })
        btIcon = ImageView(this)
        btIcon.setImageResource(R.drawable.ic_bluetooth)
        btIcon.alpha = 0.3f
        top.addView(btIcon, lp(u(20), u(20)).also { it.leftMargin = u(12) })
        top.addView(View(this), lp(0, 1).also { it.weight = 1f })
        tempTv = label(20f, 0xFFB8BDCC.toInt())
        top.addView(tempTv, lp(WRAP, WRAP).also { it.rightMargin = u(26) })
        timeTv = label(22f, Color.WHITE)
        top.addView(timeTv, lp(WRAP, WRAP))
        main.addView(top, lp(MATCH, u(46)))

        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        main.addView(body, lp(MATCH, 0).also { it.weight = 1f })

        // ---------- پنل چپ ----------
        leftPanel = LinearLayout(this)
        leftPanel.orientation = LinearLayout.VERTICAL
        leftPanel.background = roundBg(cardBase, 26)
        body.addView(leftPanel, lp(0, MATCH).also { it.weight = 0.40f; it.rightMargin = u(14) })

        pager = SlidePager(this)
        // صفحه‌ی ۱: ماشین + سرعت
        val page0 = LinearLayout(this)
        page0.orientation = LinearLayout.VERTICAL
        carView = CarView(this)
        page0.addView(carView, lp(MATCH, 0).also { it.weight = 1f })
        val sBox = LinearLayout(this)
        sBox.orientation = LinearLayout.VERTICAL
        sBox.setPadding(u(22), 0, u(22), u(8))
        speedLabel = label(15f, 0xFF8A90A0.toInt())
        speedLabel.setFa("سرعت")
        sBox.addView(speedLabel)
        val sRow = LinearLayout(this)
        sRow.orientation = LinearLayout.HORIZONTAL
        sRow.gravity = Gravity.BOTTOM
        speedTv = label(56f, Color.WHITE)
        speedTv.setFa("0", true)
        unitTv = label(20f, 0xFF8A90A0.toInt())
        sRow.addView(speedTv)
        sRow.addView(unitTv, lp(WRAP, WRAP).also { it.leftMargin = u(8); it.bottomMargin = u(10) })
        sBox.addView(sRow)
        page0.addView(sBox, lp(MATCH, WRAP))
        pager.addPage(page0)
        // صفحه‌ی ۲: سرعت‌سنج
        val page1 = FrameLayout(this)
        page1.setPadding(u(10), u(8), u(10), u(4))
        gauge = GaugeView(this)
        page1.addView(gauge, FrameLayout.LayoutParams(MATCH, MATCH))
        pager.addPage(page1)
        leftPanel.addView(pager, lp(MATCH, 0).also { it.weight = 1f })

        pageDots = PageDots(this)
        pager.onScroll = { p -> pageDots.pos = p }
        pager.onPageChanged = { i -> prefs.leftPage = i }
        leftPanel.addView(pageDots, lp(MATCH, u(12)).also { it.topMargin = u(4); it.bottomMargin = u(8) })

        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.setPadding(u(18), 0, u(18), u(16))
        val tiles = LinearLayout(this)
        tiles.orientation = LinearLayout.HORIZONTAL
        btTile = makeTile(R.drawable.ic_bluetooth, "بلوتوث")
        wifiTile = makeTile(R.drawable.ic_wifi, "Wi-Fi")
        btTile.box.setOnClickListener { radios.toggleBt(this) }
        wifiTile.box.setOnClickListener { radios.toggleWifi(this) }
        tiles.addView(btTile.box, lp(0, MATCH).also { it.weight = 1f; it.rightMargin = u(7) })
        tiles.addView(wifiTile.box, lp(0, MATCH).also { it.weight = 1f; it.leftMargin = u(7) })
        info.addView(tiles, lp(MATCH, u(112)))

        val volRow = LinearLayout(this)
        volRow.orientation = LinearLayout.HORIZONTAL
        val volLabel = label(16f, 0xFF8A90A0.toInt())
        volLabel.setFa("صدا")
        volPct = label(16f, Color.WHITE)
        volRow.addView(volLabel, lp(0, WRAP).also { it.weight = 1f })
        volRow.addView(volPct, lp(WRAP, WRAP))
        info.addView(volRow, lp(MATCH, WRAP).also { it.topMargin = u(14) })
        tickBar = TickBar(this)
        tickBar.onChange = { f ->
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            try { am.setStreamVolume(AudioManager.STREAM_MUSIC, (f * mx).roundToInt(), 0) } catch (_: Exception) {}
            volPct.setFa("" + (f * 100).roundToInt() + "%")
        }
        info.addView(tickBar, lp(MATCH, u(34)).also { it.topMargin = u(6) })
        leftPanel.addView(info, lp(MATCH, WRAP))

        // ---------- پنل راست (نقشه) ----------
        val right = FrameLayout(this)
        right.setBackgroundColor(cardBase)
        body.addView(right, lp(0, MATCH).also { it.weight = 0.60f })

        setupMap()
        right.addView(mapView, FrameLayout.LayoutParams(MATCH, MATCH))
        mask = CornerMask(this)
        mask.radius = u(26).toFloat()
        mask.color = rootBase
        right.addView(mask, FrameLayout.LayoutParams(MATCH, MATCH))

        // کارت پیچ بعدی
        instrCard = LinearLayout(this)
        instrCard.orientation = LinearLayout.VERTICAL
        instrCard.background = roundBg(blue, 14)
        instrCard.setPadding(u(16), u(10), u(18), u(12))
        instrCard.visibility = View.GONE
        val ir = LinearLayout(this)
        ir.gravity = Gravity.CENTER_VERTICAL
        instrArrow = ImageView(this)
        instrArrow.setImageResource(R.drawable.ic_turn)
        ir.addView(instrArrow, lp(u(34), u(34)))
        instrDist = label(34f, Color.WHITE)
        ir.addView(instrDist, lp(WRAP, WRAP).also { it.leftMargin = u(10) })
        instrCard.addView(ir)
        instrText = label(16f, 0xFFE6EFFF.toInt())
        instrText.maxWidth = u(330)
        instrCard.addView(instrText, lp(WRAP, WRAP).also { it.topMargin = u(2) })
        right.addView(instrCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).also {
            it.setMargins(u(18), u(18), 0, 0)
        })

        // دکمه‌ی بازگشت به موقعیت
        recenterBtn = iconButton(R.drawable.ic_nav, 48, 12)
        recenterBtn.background = rippleBg(0xCC2A2E3C.toInt(), 0, 0, true, 0f)
        recenterBtn.setOnClickListener { follow = true; recenter() }
        right.addView(recenterBtn, FrameLayout.LayoutParams(u(48), u(48), Gravity.TOP or Gravity.END).also {
            it.setMargins(0, u(18), u(18), 0)
        })

        // زوم
        val zoomBox = LinearLayout(this)
        zoomBox.orientation = LinearLayout.VERTICAL
        zoomBox.background = roundBg(0xCC2A2E3C.toInt(), 14)
        val zin = iconButton(R.drawable.ic_plus, 46, 11)
        zin.setOnClickListener { mapView.controller.zoomIn() }
        val zout = iconButton(R.drawable.ic_minus, 46, 11)
        zout.setOnClickListener { mapView.controller.zoomOut() }
        zoomBox.addView(zin, lp(u(46), u(46)))
        zoomBox.addView(zout, lp(u(46), u(46)))
        right.addView(zoomBox, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_VERTICAL or Gravity.END).also {
            it.setMargins(0, 0, u(18), u(40))
        })

        attrTv = label(9f, 0x99FFFFFF.toInt())
        attrTv.text = "© OpenStreetMap contributors"
        right.addView(attrTv, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).also {
            it.setMargins(0, 0, u(20), u(170))
        })

        // کارت‌های پایین نقشه
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        right.addView(bottom, FrameLayout.LayoutParams(MATCH, u(150), Gravity.BOTTOM).also {
            it.setMargins(u(14), 0, u(14), u(14))
        })

        // -- کارت مسیر --
        val rc = LinearLayout(this)
        rc.orientation = LinearLayout.VERTICAL
        rc.background = roundBg(0xF01A1D26.toInt(), 18)
        rc.setPadding(u(14), u(12), u(14), u(10))
        val rr = LinearLayout(this)
        rr.gravity = Gravity.CENTER_VERTICAL
        val iconBox = FrameLayout(this)
        iconBox.background = roundBg(0xFF2A2E3C.toInt(), 12)
        routeIcon = ImageView(this)
        routeIcon.setImageResource(R.drawable.ic_search)
        iconBox.addView(routeIcon, FrameLayout.LayoutParams(u(24), u(24), Gravity.CENTER))
        rr.addView(iconBox, lp(u(44), u(44)))
        val rt = LinearLayout(this)
        rt.orientation = LinearLayout.VERTICAL
        routeTitle = label(18f, Color.WHITE)
        routeTitle.setSingleLine(true)
        routeTitle.ellipsize = TextUtils.TruncateAt.END
        routeAddr = label(13f, 0xFF8A90A0.toInt())
        routeAddr.setSingleLine(true)
        routeAddr.ellipsize = TextUtils.TruncateAt.END
        rt.addView(routeTitle, lp(MATCH, WRAP))
        rt.addView(routeAddr, lp(MATCH, WRAP))
        rr.addView(rt, lp(0, WRAP).also { it.weight = 1f; it.leftMargin = u(12) })
        routeClose = label(24f, 0xFF8A90A0.toInt())
        routeClose.text = "✕"
        routeClose.setPadding(u(10), u(2), u(4), u(2))
        routeClose.setOnClickListener { clearRoute() }
        rr.addView(routeClose)
        rc.addView(rr, lp(MATCH, WRAP))
        routeBar = RouteBar(this)
        rc.addView(routeBar, lp(MATCH, u(7)).also { it.topMargin = u(10) })
        val sr = LinearLayout(this)
        sr.gravity = Gravity.CENTER_VERTICAL
        statsTv = label(20f, Color.WHITE)
        arrivalTv = label(14f, 0xFFB8BDCC.toInt())
        sr.addView(statsTv, lp(0, WRAP).also { it.weight = 1f })
        sr.addView(arrivalTv, lp(WRAP, WRAP))
        rc.addView(sr, lp(MATCH, WRAP).also { it.topMargin = u(8) })
        detailsTv = label(15f, blue)
        detailsTv.setFa("جزئیات مسیر")
        detailsTv.setOnClickListener { showDirections() }
        rc.addView(detailsTv, lp(WRAP, WRAP).also { it.topMargin = u(6) })
        rc.setOnClickListener { if (route == null) openSearch() }
        bottom.addView(rc, lp(0, MATCH).also { it.weight = 1.45f; it.rightMargin = u(10) })

        // -- کارت موزیک --
        val mc = LinearLayout(this)
        mc.orientation = LinearLayout.VERTICAL
        mc.gravity = Gravity.CENTER_HORIZONTAL
        mc.background = roundBg(0xF01A1D26.toInt(), 18)
        mc.setPadding(u(12), u(10), u(12), u(8))
        musicTitle = label(17f, Color.WHITE)
        musicTitle.setSingleLine(true)
        musicTitle.ellipsize = TextUtils.TruncateAt.MARQUEE
        musicTitle.marqueeRepeatLimit = -1
        musicTitle.isSelected = true
        musicTitle.gravity = Gravity.CENTER
        musicArtist = label(13f, 0xFF8A90A0.toInt())
        musicArtist.setSingleLine(true)
        musicArtist.gravity = Gravity.CENTER
        mc.addView(musicTitle, lp(MATCH, WRAP))
        mc.addView(musicArtist, lp(MATCH, WRAP))
        val ctl = LinearLayout(this)
        ctl.gravity = Gravity.CENTER
        val bp = iconButton(R.drawable.ic_prev, 40, 10)
        bp.setOnClickListener { music.prev() }
        btnPlay = iconButton(R.drawable.ic_pause, 52, 14)
        btnPlay.background = rippleBg(0xFF2A2E3C.toInt(), 0, 0, true, 0f)
        btnPlay.setOnClickListener { music.toggle() }
        val bn = iconButton(R.drawable.ic_next, 40, 10)
        bn.setOnClickListener { music.next() }
        ctl.addView(bp, lp(u(40), u(40)))
        ctl.addView(btnPlay, lp(u(52), u(52)).also { it.leftMargin = u(18); it.rightMargin = u(18) })
        ctl.addView(bn, lp(u(40), u(40)))
        mc.addView(ctl, lp(MATCH, WRAP).also { it.topMargin = u(4) })
        musicProgress = ProgressLine(this)
        musicProgress.onSeek = { f -> music.seek(f) }
        mc.addView(musicProgress, lp(MATCH, u(22)))
        val tr = LinearLayout(this)
        posTv = label(11f, 0xFF8A90A0.toInt())
        remTv = label(11f, 0xFF8A90A0.toInt())
        tr.addView(posTv, lp(0, WRAP).also { it.weight = 1f })
        tr.addView(remTv, lp(WRAP, WRAP))
        mc.addView(tr, lp(MATCH, WRAP))
        bottom.addView(mc, lp(0, MATCH).also { it.weight = 1f })

        // افکت اسپرت (روی همه چیز، بدون دریافت لمس)
        sport = SportOverlay(this)
        root.addView(sport, FrameLayout.LayoutParams(MATCH, MATCH))

        setContentView(root)
        builtVersion = prefs.version
    }

    // =====================================================================
    // نقشه
    private fun arrowBitmap(): Bitmap {
        val s = u(56)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val path = Path()
        val f = s.toFloat()
        path.moveTo(f / 2f, f * 0.06f)
        path.lineTo(f * 0.90f, f * 0.92f)
        path.lineTo(f / 2f, f * 0.72f)
        path.lineTo(f * 0.10f, f * 0.92f)
        path.close()
        p.color = blue
        p.style = Paint.Style.FILL
        c.drawPath(path, p)
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = f * 0.07f
        c.drawPath(path, p)
        return bmp
    }

    private fun pinBitmap(): Bitmap {
        val s = u(34)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val f = s.toFloat()
        p.color = Color.WHITE
        c.drawCircle(f / 2, f / 2, f * 0.46f, p)
        p.color = Color.parseColor("#E53935")
        c.drawCircle(f / 2, f / 2, f * 0.34f, p)
        p.color = Color.WHITE
        c.drawCircle(f / 2, f / 2, f * 0.12f, p)
        return bmp
    }

    private fun setupMap() {
        mapView = MapView(this)
        mapView.setMultiTouchControls(true)
        mapView.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        mapView.setTilesScaledToDpi(true)
        mapView.setMinZoomLevel(3.0)
        mapView.setMaxZoomLevel(19.0)
        mapView.controller.setZoom(3.5)

        routeLine = Polyline()
        routeLine.outlinePaint.color = blue
        routeLine.outlinePaint.strokeWidth = u(8).toFloat()
        routeLine.outlinePaint.strokeCap = Paint.Cap.ROUND
        routeLine.outlinePaint.strokeJoin = Paint.Join.ROUND
        mapView.overlays.add(routeLine)

        destMarker = Marker(mapView)
        destMarker.icon = BitmapDrawable(resources, pinBitmap())
        destMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        destMarker.setInfoWindow(null)

        carMarker = Marker(mapView)
        carMarker.icon = BitmapDrawable(resources, arrowBitmap())
        carMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        carMarker.setInfoWindow(null)
        mapView.overlays.add(carMarker)

        val ll = lastKnown()
        if (ll != null) {
            carMarker.position = GeoPoint(ll.latitude, ll.longitude)
            mapView.controller.setZoom(15.5)
            mapView.controller.setCenter(carMarker.position)
            firstFix = true
        }

        // لمس: کشیدن نقشه = توقف دنبال‌کردن؛ نگه‌داشتن طولانی = انتخاب مقصد
        mapView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    cancelLong()
                    val r = Runnable { onMapLongPress(downX, downY) }
                    longRun = r
                    handler.postDelayed(r, 750)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(ev.x - downX) > u(14) || abs(ev.y - downY) > u(14)) {
                        cancelLong()
                        if (follow) {
                            follow = false
                            recenterBtn.alpha = 1f
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> cancelLong()
            }
            false
        }
    }

    private fun cancelLong() {
        val r = longRun
        if (r != null) handler.removeCallbacks(r)
        longRun = null
    }

    private fun applyMapStyle() {
        val key = prefs.cartoKey.trim()
        val style = prefs.mapStyle
        if (style == 2 && key.isNotEmpty()) {
            mapView.setTileSource(
                XYTileSource(
                    "CartoDarkKey", 0, 19, 256, ".png?key=" + key,
                    arrayOf("https://basemaps.cartocdn.com/rastertiles/dark_all/")
                )
            )
            mapView.overlayManager.tilesOverlay.setColorFilter(null)
            attrTv.text = "© OpenStreetMap contributors © CARTO"
        } else if (style == 1) {
            mapView.setTileSource(TileSourceFactory.MAPNIK)
            mapView.overlayManager.tilesOverlay.setColorFilter(null)
            attrTv.text = "© OpenStreetMap contributors"
        } else {
            // پیش‌فرض: نقشه‌ی OpenStreetMap با رنگ‌های وارونه = نقشه‌ی تیره (بدون نیاز به کلید)
            mapView.setTileSource(TileSourceFactory.MAPNIK)
            mapView.overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)
            attrTv.text = "© OpenStreetMap contributors"
        }
        mapView.invalidate()
    }

    private fun recenter() {
        val l = lastLoc
        if (l != null) {
            mapView.controller.animateTo(GeoPoint(l.latitude, l.longitude))
        } else {
            val ll = lastKnown()
            if (ll != null) mapView.controller.animateTo(GeoPoint(ll.latitude, ll.longitude))
        }
        recenterBtn.alpha = 0.6f
    }

    private fun onMapLongPress(x: Float, y: Float) {
        val gp = mapView.projection.fromPixels(x.toInt(), y.toInt())
        val lat = gp.latitude
        val lon = gp.longitude
        Thread {
            val d = try { Nav.reverse(lat, lon) } catch (e: Exception) { Dest("نقطه‌ی انتخابی", "", lat, lon) }
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("مسیریابی به این نقطه؟")
                    .setMessage(d.name)
                    .setPositiveButton("بله") { _, _ -> startRoute(d) }
                    .setNegativeButton("خیر", null)
                    .show()
            }
        }.start()
    }

    // =====================================================================
    // مسیریابی
    private fun openSearch() {
        val i = Intent(this, SearchActivity::class.java)
        val l = lastLoc ?: lastKnown()
        if (l != null) {
            i.putExtra("lat", l.latitude)
            i.putExtra("lon", l.longitude)
        }
        startActivityForResult(i, 500)
    }

    private fun startRoute(d: Dest) {
        val l = lastLoc ?: lastKnown()
        val fLat: Double
        val fLon: Double
        if (l != null) {
            fLat = l.latitude
            fLon = l.longitude
        } else {
            val c = mapView.mapCenter
            fLat = c.latitude
            fLon = c.longitude
        }
        dest = d
        routeTitle.setFa(d.name, true)
        routeAddr.setFa("در حال مسیریابی...")
        Thread {
            try {
                val r = Nav.route(fLat, fLon, d.lat, d.lon)
                runOnUiThread {
                    if (r == null) {
                        toast("مسیری پیدا نشد.")
                        clearRoute()
                    } else {
                        applyRoute(r, d, true)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    toast("خطا در مسیریابی. اینترنت را بررسی کنید.")
                    clearRoute()
                }
            }
        }.start()
    }

    private fun applyRoute(r: Route, d: Dest, overview: Boolean) {
        route = r
        tracker = RouteTracker(r)
        val pts = ArrayList<GeoPoint>()
        for (i in r.lats.indices) pts.add(GeoPoint(r.lats[i], r.lons[i]))
        routeLine.setPoints(pts)
        destMarker.position = GeoPoint(d.lat, d.lon)
        if (!destOnMap) {
            mapView.overlays.add(mapView.overlays.size - 1, destMarker)
            destOnMap = true
        }
        routeTitle.setFa(d.name, true)
        routeAddr.setFa(d.addr)
        routeIcon.setImageResource(R.drawable.ic_flag)
        routeClose.visibility = View.VISIBLE
        routeBar.visibility = View.VISIBLE
        statsTv.visibility = View.VISIBLE
        arrivalTv.visibility = View.VISIBLE
        detailsTv.visibility = View.VISIBLE
        instrCard.visibility = View.VISIBLE
        if (overview) {
            follow = false
            mapView.mapOrientation = 0f
            orient = 0f
            try {
                mapView.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, u(80))
            } catch (e: Exception) {
            }
            handler.postDelayed({
                if (route != null) {
                    follow = true
                    recenter()
                }
            }, 6000)
        }
        val l = lastLoc
        if (l != null) {
            val p = RouteTracker(r).update(l.latitude, l.longitude, l.accuracy)
            showProgress(p)
        } else {
            showProgress(Progress(0, r.distance, r.duration, 0.0, r.steps.getOrNull(1)?.startDist ?: 0.0, r.steps.getOrNull(1)))
        }
        mapView.invalidate()
    }

    private fun clearRoute() {
        route = null
        tracker = null
        dest = null
        routeLine.setPoints(ArrayList<GeoPoint>())
        if (destOnMap) {
            mapView.overlays.remove(destMarker)
            destOnMap = false
        }
        instrCard.visibility = View.GONE
        routeTitle.setFa("مقصد را جستجو کنید", true)
        routeAddr.setFa("یا روی نقشه نگه دارید")
        routeIcon.setImageResource(R.drawable.ic_search)
        routeClose.visibility = View.GONE
        routeBar.visibility = View.INVISIBLE
        statsTv.visibility = View.INVISIBLE
        arrivalTv.visibility = View.INVISIBLE
        detailsTv.visibility = View.INVISIBLE
        mapView.invalidate()
    }

    private fun reroute() {
        val d = dest ?: return
        val l = lastLoc ?: return
        lastReroute = SystemClock.elapsedRealtime()
        Thread {
            try {
                val r = Nav.route(l.latitude, l.longitude, d.lat, d.lon)
                if (r != null) runOnUiThread { applyRoute(r, d, false) }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun showProgress(p: Progress) {
        val nx = p.next
        if (nx != null) {
            instrArrow.rotation = Nav.arrowAngle(nx.type, nx.modifier)
            instrDist.setFa(Nav.fmtDist(p.distToNext), true)
            instrText.setFa(nx.text)
        }
        routeBar.fraction = p.fraction.toFloat()
        val s = Nav.fmtDist(p.remaining) + "  •  " + Nav.fmtDur(p.remainingTime)
        statsTv.setFa(s, true)
        val sp = SpannableString(s)
        val k = s.indexOf("•")
        if (k >= 0) sp.setSpan(ForegroundColorSpan(blue), k + 3, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        statsTv.text = sp
        val eta = Date(System.currentTimeMillis() + (p.remainingTime * 1000).toLong())
        val fmt = SimpleDateFormat(if (prefs.clock24) "HH:mm" else "hh:mm a", Locale.ENGLISH)
        arrivalTv.setFa("زمان رسیدن  " + fmt.format(eta))
    }

    private fun showDirections() {
        val r = route ?: return
        val items = r.steps.map { Nav.fmtDist(it.dist) + "   " + it.text }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(dest?.name ?: "مسیر")
            .setItems(items) { _, _ -> }
            .show()
    }

    // =====================================================================
    // موقعیت
    private fun handleLocation(l: Location) {
        lastLoc = l
        lastLocAt = SystemClock.elapsedRealtime()
        curKmh = if (l.hasSpeed()) l.speed * 3.6f else 0f
        if (curKmh < 3f) curKmh = 0f
        showSpeed()
        val gp = GeoPoint(l.latitude, l.longitude)
        carMarker.position = gp
        if (!firstFix) {
            firstFix = true
            mapView.controller.setZoom(16.0)
            mapView.controller.setCenter(gp)
        }
        if (follow) {
            mapView.controller.animateTo(gp)
            if (!prefs.northUp && l.hasBearing() && l.speed > 1.5f) {
                val tgt = -l.bearing
                val diff = ((tgt - orient + 540f) % 360f) - 180f
                orient += diff * 0.35f
                mapView.mapOrientation = orient
            }
        }
        val tr = tracker
        if (tr != null) {
            val p = tr.update(l.latitude, l.longitude, l.accuracy)
            showProgress(p)
            val now = SystemClock.elapsedRealtime()
            if (p.offCount >= 3 && now - lastReroute > 12000) reroute()
            val nx = p.next
            if (p.remaining < 35 && nx != null && nx.type == "arrive") {
                toast("به مقصد رسیدید")
                clearRoute()
            }
        }
        mapView.invalidate()
    }

    private fun showSpeed() {
        val disp = if (prefs.speedUnit == 1) curKmh * 0.621371f else curKmh
        speedTv.setFa("" + disp.roundToInt(), true)
        gauge.setSpeed(disp)
        updateSport(curKmh)
    }

    private fun granted(p: String) =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        if (Build.VERSION.SDK_INT < 23 || askedPerms) return
        askedPerms = true
        val need = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION, music.audioPerm()
        ).filter { !granted(it) }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        music.loadIfPermitted()
        startLocation()
    }

    private fun startLocation() {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            locationManager = lm
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 0f, locListener)
            }
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    private fun stopLocation() {
        try { locationManager?.removeUpdates(locListener) } catch (_: Exception) {}
    }

    private fun lastKnown(): Location? {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) return null
        return try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (e: Exception) {
            null
        }
    }

    // =====================================================================
    // تنظیمات و افکت اسپرت
    private fun applyPrefs() {
        builtVersion = prefs.version
        applyMapStyle()
        // تصویر ماشین
        val f = File(filesDir, "car.png")
        carView.image = if (f.exists()) {
            try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null }
        } else null
        // واحد سرعت
        if (prefs.speedUnit == 1) {
            gauge.maxValue = 160f
            gauge.labelStep = 20
            gauge.minorStep = 10
            gauge.unit = "MPH"
            unitTv.setFa("mph", true)
        } else {
            gauge.maxValue = 240f
            gauge.labelStep = 40
            gauge.minorStep = 10
            gauge.unit = "km/h"
            unitTv.setFa("km/h", true)
        }
        gauge.limit = prefs.speedLimit
        tempTv.visibility = if (prefs.showWeather) View.VISIBLE else View.GONE
        pager.post { pager.goTo(prefs.leftPage, false) }
        sportTarget = -1f
        showSpeed()
        if (!prefs.sportFx) applySport(0f)
        clearRouteIfIdle()
    }

    private fun clearRouteIfIdle() {
        if (route == null) clearRoute()
    }

    private fun updateSport(kmh: Float) {
        val t = if (prefs.sportFx) ((kmh - 30f) / 100f).coerceIn(0f, 1f) else 0f
        if (abs(t - sportTarget) < 0.02f) return
        sportTarget = t
        sportAnim?.cancel()
        val a = ValueAnimator.ofFloat(sportT, t)
        a.duration = 900
        a.addUpdateListener {
            sportT = it.animatedValue as Float
            applySport(sportT)
        }
        a.start()
        sportAnim = a
    }

    private fun applySport(t: Float) {
        sportT = t
        val rb = blendColors(rootBase, rootHot, t)
        root.setBackgroundColor(rb)
        mask.color = rb
        sideBar.setBackgroundColor(blendColors(0xFF151821.toInt(), 0xFF22090D.toInt(), t))
        leftPanel.background = roundBg(blendColors(cardBase, cardHot, t), 26)
        carView.glow = blendColors(Color.parseColor("#335CFF"), hotRed, t)
        tickBar.accent = blendColors(blue, hotRed, t)
        pageDots.accent = blendColors(blue, hotRed, t)
        sport.t = t
    }

    // =====================================================================
    // تیک دوره‌ای
    private fun tick() {
        val fmt = SimpleDateFormat(if (prefs.clock24) "HH:mm" else "hh:mm a", Locale.ENGLISH)
        timeTv.setFa(fmt.format(Date()), true)

        val bt = radios.btOn()
        setTile(btTile, bt, if (bt) "روشن" else "خاموش")
        btIcon.alpha = if (bt) 1f else 0.3f
        val w = radios.wifiOn()
        setTile(wifiTile, w, if (w) (radios.ssid() ?: "روشن") else "خاموش")
        val net = radios.network()
        netTv.setFa(net.first)
        statusDots.level = net.second

        if (lastLoc != null && SystemClock.elapsedRealtime() - lastLocAt > 5000 && curKmh != 0f) {
            curKmh = 0f
            showSpeed()
        }

        if (!tickBar.dragging) {
            val mx = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val f = if (mx > 0) cur.toFloat() / mx else 0f
            tickBar.fraction = f
            volPct.setFa("" + (f * 100).roundToInt() + "%")
        }

        updateMusic()
        maybeWeather()
    }

    private fun updateMusic() {
        music.decide()
        musicTitle.setFa(music.title, true)
        musicArtist.setFa(music.artist)
        btnPlay.setImageResource(if (music.playing) R.drawable.ic_pause else R.drawable.ic_play)
        val d = music.dur
        val p = music.pos
        if (!musicProgress.dragging) musicProgress.fraction = if (d > 0) p.toFloat() / d else 0f
        posTv.setFa(formatTime(p))
        remTv.setFa(if (d > 0) "-" + formatTime(d - p) else "")
    }

    private fun maybeWeather() {
        if (!prefs.showWeather) return
        val now = SystemClock.elapsedRealtime()
        if (weatherAt != 0L && now - weatherAt < 30 * 60 * 1000L) return
        val loc = lastLoc ?: lastKnown() ?: return
        weatherAt = now
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=" + loc.latitude + "&longitude=" + loc.longitude +
                        "&current=temperature_2m"
                )
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val txt = c.inputStream.bufferedReader().readText()
                c.disconnect()
                val temp = JSONObject(txt).getJSONObject("current").getDouble("temperature_2m").roundToInt()
                runOnUiThread { tempTv.setFa("" + temp + "°C") }
            } catch (e: Exception) {
                weatherAt = now - 25 * 60 * 1000L
            }
        }.start()
    }

    // =====================================================================
    private fun pickApp(req: Int) {
        startActivityForResult(Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK, true), req)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        if (req == 201) {
            val pkg = data.getStringExtra(AppsActivity.EXTRA_PKG)
            if (pkg != null) prefs.phonePkg = pkg
        } else if (req == 500) {
            val d = Dest(
                data.getStringExtra("name") ?: "",
                data.getStringExtra("addr") ?: "",
                data.getDoubleExtra("lat", 0.0),
                data.getDoubleExtra("lon", 0.0)
            )
            startRoute(d)
        }
    }
}
