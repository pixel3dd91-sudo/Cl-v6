package com.carlauncher.player

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

data class Dest(val name: String, val addr: String, val lat: Double, val lon: Double)

class Step(
    val text: String, val dist: Double, val lat: Double, val lon: Double,
    val type: String, val modifier: String, val startDist: Double
)

class Route(
    val lats: DoubleArray, val lons: DoubleArray, val cum: DoubleArray,
    val distance: Double, val duration: Double, val steps: List<Step>
)

class Progress(
    val offCount: Int, val remaining: Double, val remainingTime: Double,
    val fraction: Double, val distToNext: Double, val next: Step?
)

/** مسیریابی با OSRM و جستجوی آدرس با Nominatim (هر دو رایگان و مبتنی بر OpenStreetMap) */
object Nav {
    const val UA = "CarDashLauncher/3.0 (personal use)"

    fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 15000
        c.setRequestProperty("User-Agent", UA)
        c.setRequestProperty("Accept-Language", "fa,en")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    fun haversine(la1: Double, lo1: Double, la2: Double, lo2: Double): Double {
        val r = 6371000.0
        val p1 = Math.toRadians(la1)
        val p2 = Math.toRadians(la2)
        val dp = p2 - p1
        val dl = Math.toRadians(lo2 - lo1)
        val a = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
        return 2 * r * asin(min(1.0, sqrt(a)))
    }

    /** فاصله‌ی نقطه تا پاره‌خط (متر) و موقعیت تصویر روی پاره‌خط (0..1) */
    fun distToSegment(pLat: Double, pLon: Double, aLat: Double, aLon: Double, bLat: Double, bLon: Double): DoubleArray {
        val k = cos(Math.toRadians(aLat))
        val px = (pLon - aLon) * k * 111320.0
        val py = (pLat - aLat) * 110540.0
        val bx = (bLon - aLon) * k * 111320.0
        val by = (bLat - aLat) * 110540.0
        val len2 = bx * bx + by * by
        var t = if (len2 > 0.0) (px * bx + py * by) / len2 else 0.0
        t = max(0.0, min(1.0, t))
        val dx = px - bx * t
        val dy = py - by * t
        return doubleArrayOf(sqrt(dx * dx + dy * dy), t)
    }

    fun route(fLat: Double, fLon: Double, tLat: Double, tLon: Double): Route? {
        val url = "https://router.project-osrm.org/route/v1/driving/" + fLon + "," + fLat + ";" + tLon + "," + tLat +
            "?overview=full&geometries=geojson&steps=true"
        val j = JSONObject(http(url))
        if (j.optString("code") != "Ok") return null
        val r = j.getJSONArray("routes").getJSONObject(0)
        val coords = r.getJSONObject("geometry").getJSONArray("coordinates")
        val n = coords.length()
        if (n < 2) return null
        val lats = DoubleArray(n)
        val lons = DoubleArray(n)
        val cum = DoubleArray(n)
        for (i in 0 until n) {
            val c = coords.getJSONArray(i)
            lons[i] = c.getDouble(0)
            lats[i] = c.getDouble(1)
            if (i > 0) cum[i] = cum[i - 1] + haversine(lats[i - 1], lons[i - 1], lats[i], lons[i])
        }
        val steps = ArrayList<Step>()
        var acc = 0.0
        val legs = r.getJSONArray("legs")
        for (li in 0 until legs.length()) {
            val st = legs.getJSONObject(li).getJSONArray("steps")
            for (si in 0 until st.length()) {
                val s = st.getJSONObject(si)
                val m = s.getJSONObject("maneuver")
                val loc = m.getJSONArray("location")
                val type = m.optString("type")
                val mod = m.optString("modifier")
                val d = s.optDouble("distance", 0.0)
                steps.add(
                    Step(
                        instruction(type, mod, s.optString("name"), m.optInt("exit", 0)),
                        d, loc.getDouble(1), loc.getDouble(0), type, mod, acc
                    )
                )
                acc += d
            }
        }
        return Route(lats, lons, cum, r.getDouble("distance"), r.getDouble("duration"), steps)
    }

    fun search(q: String, lat: Double, lon: Double): List<Dest> {
        val sb = StringBuilder("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=8&q=")
        sb.append(URLEncoder.encode(q, "UTF-8"))
        if (lat != 0.0 || lon != 0.0) {
            sb.append("&viewbox=").append(lon - 1.0).append(",").append(lat + 1.0).append(",")
                .append(lon + 1.0).append(",").append(lat - 1.0)
        }
        val arr = JSONArray(http(sb.toString()))
        val out = ArrayList<Dest>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val dn = o.optString("display_name")
            val nm = o.optString("name")
            val name = if (nm.isNotEmpty()) nm else dn.substringBefore(",")
            out.add(Dest(name, dn, o.getString("lat").toDouble(), o.getString("lon").toDouble()))
        }
        return out
    }

    fun reverse(lat: Double, lon: Double): Dest {
        val o = JSONObject(http("https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=" + lat + "&lon=" + lon))
        val dn = o.optString("display_name")
        val nm = o.optString("name")
        val name = if (nm.isNotEmpty()) nm else if (dn.isNotEmpty()) dn.substringBefore(",") else "نقطه‌ی انتخابی"
        return Dest(name, dn, lat, lon)
    }

    fun instruction(type: String, mod: String, name: String, exit: Int): String {
        val onto = if (name.isNotEmpty()) " به " + name else ""
        val dir = when (mod) {
            "left" -> "به چپ"
            "right" -> "به راست"
            "slight left" -> "کمی به چپ"
            "slight right" -> "کمی به راست"
            "sharp left" -> "کاملاً به چپ"
            "sharp right" -> "کاملاً به راست"
            else -> ""
        }
        return when (type) {
            "depart" -> if (name.isNotEmpty()) "حرکت کنید در " + name else "حرکت کنید"
            "arrive" -> "به مقصد می‌رسید"
            "roundabout", "rotary", "roundabout turn" ->
                if (exit > 0) "در میدان از خروجی " + exit + " خارج شوید" else "وارد میدان شوید"
            "merge" -> "ادغام شوید" + onto
            "fork" -> if (dir.isNotEmpty()) "از دوراهی " + dir + " بروید" + onto else "از دوراهی ادامه دهید"
            else -> when {
                mod == "uturn" -> "دور بزنید"
                dir.isNotEmpty() -> dir + " بپیچید" + onto
                else -> "مستقیم ادامه دهید" + onto
            }
        }
    }

    fun arrowAngle(type: String, mod: String): Float {
        if (type == "arrive") return 0f
        return when (mod) {
            "right" -> 90f
            "slight right" -> 45f
            "sharp right" -> 135f
            "left" -> 270f
            "slight left" -> 315f
            "sharp left" -> 225f
            "uturn" -> 180f
            else -> 0f
        }
    }

    fun fmtDist(m: Double): String {
        if (m < 1000) {
            val v = if (m >= 100) (m / 10).roundToInt() * 10 else (m / 5).roundToInt() * 5
            return "$v m"
        }
        if (m >= 10000) return "" + (m / 1000).roundToInt() + " km"
        return String.format(Locale.US, "%.1f km", m / 1000)
    }

    fun fmtDur(s: Double): String {
        val mins = (s / 60).roundToInt()
        if (mins < 60) return "$mins min"
        return "" + (mins / 60) + " h " + (mins % 60) + " min"
    }
}

/** پیگیری پیشرفت روی مسیر: فاصله‌ی باقی‌مانده، پیچ بعدی، خارج‌شدن از مسیر */
class RouteTracker(val route: Route) {
    private var idx = 0
    private var off = 0
    private val total = route.cum[route.cum.size - 1]

    fun update(lat: Double, lon: Double, acc: Float): Progress {
        val n = route.lats.size
        var best = Double.MAX_VALUE
        var bestI = idx
        var bestT = 0.0

        fun scan(from: Int, to: Int) {
            var i = from
            while (i <= to) {
                val r = Nav.distToSegment(
                    lat, lon, route.lats[i], route.lons[i], route.lats[i + 1], route.lons[i + 1]
                )
                if (r[0] < best) {
                    best = r[0]
                    bestI = i
                    bestT = r[1]
                }
                i++
            }
        }

        val thr = max(45.0, acc * 1.5)
        scan(max(0, idx - 3), min(n - 2, idx + 120))
        if (best > thr) scan(0, n - 2)
        if (best > thr) {
            off++
        } else {
            off = 0
            idx = bestI
        }

        val along = route.cum[bestI] + (route.cum[bestI + 1] - route.cum[bestI]) * bestT
        val remaining = max(0.0, total - along)
        val fraction = if (total > 0) min(1.0, along / total) else 0.0
        val roadAlong = along * (route.distance / max(1.0, total))

        var nxt: Step? = null
        for (s in route.steps) {
            if (s.startDist > roadAlong + 8.0) {
                nxt = s
                break
            }
        }
        if (nxt == null) nxt = route.steps.lastOrNull()
        val toNext = if (nxt != null) max(0.0, nxt.startDist - roadAlong) else 0.0
        val remTime = if (total > 0) route.duration * (remaining / total) else 0.0
        return Progress(off, remaining, remTime, fraction, toNext, nxt)
    }
}
