package com.carlauncher.player

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.provider.Settings
import android.widget.Toast

/** روشن/خاموش کردن بلوتوث و وای‌فای. اگر اندروید اجازه ندهد، صفحه‌ی تنظیمات سیستم باز می‌شود. */
class Radios(ctx: Context) {
    private val app = ctx.applicationContext
    private val wifi = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val bt: BluetoothAdapter? = try { BluetoothAdapter.getDefaultAdapter() } catch (e: Throwable) { null }

    fun btOn(): Boolean = try { bt?.isEnabled == true } catch (e: Throwable) { false }
    fun wifiOn(): Boolean = try { wifi.isWifiEnabled } catch (e: Throwable) { false }

    @Suppress("DEPRECATION")
    fun toggleBt(a: Activity) {
        var ok = false
        try {
            val ad = bt
            if (ad != null) ok = if (ad.isEnabled) ad.disable() else ad.enable()
        } catch (e: Throwable) {
            ok = false
        }
        if (!ok) openSettings(a, Settings.ACTION_BLUETOOTH_SETTINGS)
    }

    @Suppress("DEPRECATION")
    fun toggleWifi(a: Activity) {
        var ok = false
        try {
            ok = wifi.setWifiEnabled(!wifi.isWifiEnabled)
        } catch (e: Throwable) {
            ok = false
        }
        if (!ok) openSettings(a, Settings.ACTION_WIFI_SETTINGS)
    }

    private fun openSettings(a: Activity, action: String) {
        try {
            a.startActivity(Intent(action))
            Toast.makeText(a, "این دستگاه اجازه‌ی تغییر مستقیم نمی‌دهد؛ از تنظیمات سیستم تغییر دهید.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(a, "باز کردن تنظیمات ممکن نشد.", Toast.LENGTH_LONG).show()
        }
    }

    fun ssid(): String? {
        try {
            val s = wifi.connectionInfo?.ssid ?: return null
            val t = s.trim('"')
            if (t.isEmpty() || t == "<unknown ssid>") return null
            return t
        } catch (e: Throwable) {
            return null
        }
    }

    /** نام شبکه‌ی فعال و سطح سیگنال (0 تا 3) */
    @Suppress("DEPRECATION")
    fun network(): Pair<String, Int> {
        try {
            val ni = cm.activeNetworkInfo
            if (ni == null || !ni.isConnected) return Pair("آفلاین", 0)
            if (ni.type == ConnectivityManager.TYPE_WIFI) {
                val rssi = wifi.connectionInfo?.rssi ?: -70
                return Pair("Wi-Fi", WifiManager.calculateSignalLevel(rssi, 3) + 1)
            }
            return Pair("LTE", 3)
        } catch (e: Throwable) {
            return Pair("آفلاین", 0)
        }
    }
}
