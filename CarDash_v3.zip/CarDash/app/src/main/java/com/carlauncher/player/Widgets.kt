package com.carlauncher.player

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.os.SystemClock
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

fun Context.roundBg(color: Int, rU: Int): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.setCornerRadius(u(rU).toFloat())
    return g
}

// ======================================================================
/** نوار تنظیم صدا: خط‌های ریز با دستگیره */
class TickBar @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var fraction = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var accent: Int = Color.parseColor("#2F7BFF")
        set(v) { field = v; invalidate() }
    var dragging = false
        private set
    var onChange: ((Float) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val n = 56
        val w = width.toFloat()
        val h = height.toFloat()
        val slot = w / n
        val tw = max(2f, slot * 0.36f)
        for (i in 0 until n) {
            val f = (i + 0.5f) / n
            p.color = if (f <= fraction) accent else 0xFF343949.toInt()
            val th = h * 0.58f
            val x = i * slot + (slot - tw) / 2f
            c.drawRoundRect(x, (h - th) / 2f, x + tw, (h + th) / 2f, tw / 2f, tw / 2f, p)
        }
        val hx = fraction * w
        val hw = context.u(4).toFloat()
        p.color = blendColors(accent, Color.WHITE, 0.35f)
        c.drawRoundRect(hx - hw / 2f, 0f, hx + hw / 2f, h, hw / 2f, hw / 2f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val f = (e.x / max(1, width)).coerceIn(0f, 1f)
        when (e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                fraction = f
                onChange?.invoke(f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                invalidate()
            }
        }
        return true
    }
}

// ======================================================================
/** نوار پیشرفت مسیر: بخش طی‌شده خاکستری، باقی‌مانده آبی */
class RouteBar @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var fraction = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = Color.parseColor("#2F7BFF")
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        p.color = 0xFF454A5C.toInt()
        c.drawRoundRect(0f, 0f, max(h, w * fraction), h, h / 2f, h / 2f, p)
    }
}

// ======================================================================
/** سه نقطه‌ی سیگنال بالای صفحه */
class DotsView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var level = 3
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val r = height / 2f
        for (i in 0 until 3) {
            p.color = if (i < level) 0xFFD5D9E6.toInt() else 0xFF4A4F60.toInt()
            c.drawCircle(r + i * (width - 2 * r) / 2f, r, r, p)
        }
    }
}

/** نقطه‌های راهنمای صفحه‌ها */
class PageDots @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var count = 2
        set(v) { field = v; invalidate() }
    var pos = 0f
        set(v) { field = v; invalidate() }
    var accent: Int = Color.parseColor("#2F7BFF")
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val r = height / 2f
        val gap = r * 3.2f
        val total = (count - 1) * gap
        val x0 = width / 2f - total / 2f
        for (i in 0 until count) {
            val near = 1f - min(1f, abs(i - pos))
            p.color = blendColors(0xFF4A4F60.toInt(), accent, near)
            c.drawCircle(x0 + i * gap, r, r * (0.75f + 0.35f * near), p)
        }
    }
}

// ======================================================================
/** صفحه‌های قابل سوایپ افقی (ماشین / سرعت‌سنج) */
class SlidePager(ctx: Context) : FrameLayout(ctx) {
    var pos = 0f
        private set
    var onScroll: ((Float) -> Unit)? = null
    var onPageChanged: ((Int) -> Unit)? = null

    private var downX = 0f
    private var downY = 0f
    private var startPos = 0f
    private var dragging = false
    private var vt: VelocityTracker? = null
    private var anim: ValueAnimator? = null
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    init {
        outlineProvider = ViewOutlineProvider.BOUNDS
        clipToOutline = true
    }

    fun addPage(v: View) {
        addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
        applyPos()
    }

    private fun applyPos() {
        for (i in 0 until childCount) getChildAt(i).translationX = (i - pos) * width
        onScroll?.invoke(pos)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        applyPos()
    }

    fun goTo(i: Int, animate: Boolean) {
        val target = i.coerceIn(0, max(0, childCount - 1)).toFloat()
        anim?.cancel()
        if (!animate) {
            pos = target
            applyPos()
            return
        }
        val a = ValueAnimator.ofFloat(pos, target)
        a.duration = 260
        a.addUpdateListener {
            pos = it.animatedValue as Float
            applyPos()
        }
        a.start()
        anim = a
        onPageChanged?.invoke(target.toInt())
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            downX = ev.x
            downY = ev.y
            dragging = false
        } else if (ev.actionMasked == MotionEvent.ACTION_MOVE) {
            if (!dragging && abs(ev.x - downX) > slop && abs(ev.x - downX) > abs(ev.y - downY)) {
                dragging = true
                anim?.cancel()
                startPos = pos
                downX = ev.x
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(ev)
            }
        }
        return dragging
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                dragging = false
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(ev)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(ev)
                if (!dragging && abs(ev.x - downX) > slop) {
                    dragging = true
                    anim?.cancel()
                    startPos = pos
                    downX = ev.x
                }
                if (dragging) {
                    pos = (startPos - (ev.x - downX) / max(1, width)).coerceIn(-0.15f, childCount - 1 + 0.15f)
                    applyPos()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.addMovement(ev)
                vt?.computeCurrentVelocity(1000)
                val vx = vt?.xVelocity ?: 0f
                vt?.recycle()
                vt = null
                if (dragging) {
                    var target = pos.roundToInt()
                    if (abs(vx) > 700f) {
                        target = if (vx < 0) ceil(pos.toDouble()).toInt() else floor(pos.toDouble()).toInt()
                    }
                    dragging = false
                    goTo(target, true)
                }
                return true
            }
        }
        return true
    }
}

// ======================================================================
/** ماشین از نمای بالا (رسم‌شده با کد) یا تصویر دلخواه کاربر */
class CarView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var image: Bitmap? = null
        set(v) { field = v; invalidate() }
    var glow: Int = Color.parseColor("#335CFF")
        set(v) { field = v; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f

        // نور زیر ماشین
        val gc = Color.argb(0x70, Color.red(glow), Color.green(glow), Color.blue(glow))
        val gc0 = Color.argb(0, Color.red(glow), Color.green(glow), Color.blue(glow))
        paint.shader = RadialGradient(cx, h * 0.70f, w * 0.65f, intArrayOf(gc, gc0), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        val bm = image
        if (bm != null) {
            val s = min(w * 0.86f / bm.width, h * 0.98f / bm.height)
            val bw = bm.width * s
            val bh = bm.height * s
            c.drawBitmap(bm, null, RectF(cx - bw / 2f, h * 0.02f, cx + bw / 2f, h * 0.02f + bh), paint)
            return
        }

        val bw = min(w * 0.60f, h * 0.46f)
        val bl = bw * 2.2f
        val x0 = cx - bw / 2f
        val y0 = h * 0.99f - bl

        // چرخ‌ها
        paint.color = 0xFF0B0C10.toInt()
        for (yy in floatArrayOf(0.12f, 0.70f)) {
            c.drawRoundRect(x0 - bw * 0.03f, y0 + bl * yy, x0 + bw * 0.07f, y0 + bl * (yy + 0.14f), bw * 0.03f, bw * 0.03f, paint)
            c.drawRoundRect(x0 + bw * 0.93f, y0 + bl * yy, x0 + bw * 1.03f, y0 + bl * (yy + 0.14f), bw * 0.03f, bw * 0.03f, paint)
        }

        // بدنه
        path.reset()
        path.moveTo(x0 + bw * 0.12f, y0)
        path.lineTo(x0 + bw * 0.88f, y0)
        path.quadTo(x0 + bw, y0 + bl * 0.05f, x0 + bw, y0 + bl * 0.30f)
        path.lineTo(x0 + bw * 0.97f, y0 + bl * 0.62f)
        path.cubicTo(x0 + bw * 0.95f, y0 + bl * 0.85f, x0 + bw * 0.78f, y0 + bl * 0.97f, cx, y0 + bl * 0.995f)
        path.cubicTo(x0 + bw * 0.22f, y0 + bl * 0.97f, x0 + bw * 0.05f, y0 + bl * 0.85f, x0 + bw * 0.03f, y0 + bl * 0.62f)
        path.lineTo(x0, y0 + bl * 0.30f)
        path.quadTo(x0, y0 + bl * 0.05f, x0 + bw * 0.12f, y0)
        path.close()
        paint.shader = LinearGradient(
            x0, 0f, x0 + bw, 0f,
            intArrayOf(0xFF0A3CB8.toInt(), 0xFF2E86FF.toInt(), 0xFF0A3CB8.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(path, paint)
        paint.shader = null

        // سقف
        paint.shader = LinearGradient(
            0f, y0 + bl * 0.18f, 0f, y0 + bl * 0.50f,
            0xFF7A83AA.toInt(), 0xFF3A425F.toInt(), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(cx - bw * 0.31f, y0 + bl * 0.18f, cx + bw * 0.31f, y0 + bl * 0.50f, bw * 0.12f, bw * 0.12f, paint)
        paint.shader = null

        // شیشه‌ی جلو
        path.reset()
        path.moveTo(cx - bw * 0.35f, y0 + bl * 0.50f)
        path.lineTo(cx + bw * 0.35f, y0 + bl * 0.50f)
        path.lineTo(cx + bw * 0.28f, y0 + bl * 0.64f)
        path.lineTo(cx - bw * 0.28f, y0 + bl * 0.64f)
        path.close()
        paint.color = 0xFF0E1220.toInt()
        c.drawPath(path, paint)

        // نور کاپوت
        paint.shader = RadialGradient(
            cx, y0 + bl * 0.78f, bw * 0.42f,
            intArrayOf(0x55FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP
        )
        c.drawOval(RectF(cx - bw * 0.42f, y0 + bl * 0.66f, cx + bw * 0.42f, y0 + bl * 0.90f), paint)
        paint.shader = null

        // چراغ‌ها و آینه‌ها
        paint.color = 0xFFEAF2FF.toInt()
        c.drawOval(RectF(x0 + bw * 0.12f, y0 + bl * 0.89f, x0 + bw * 0.34f, y0 + bl * 0.93f), paint)
        c.drawOval(RectF(x0 + bw * 0.66f, y0 + bl * 0.89f, x0 + bw * 0.88f, y0 + bl * 0.93f), paint)
        paint.color = 0xFF10131C.toInt()
        c.drawOval(RectF(x0 - bw * 0.05f, y0 + bl * 0.50f, x0 + bw * 0.06f, y0 + bl * 0.56f), paint)
        c.drawOval(RectF(x0 + bw * 0.94f, y0 + bl * 0.50f, x0 + bw * 1.05f, y0 + bl * 0.56f), paint)
    }
}

// ======================================================================
/** سرعت‌سنج دایره‌ای: کمان قرمز، عددهای دور صفحه، عدد بزرگ وسط و تابلوی محدودیت */
class GaugeView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    var maxValue = 240f
        set(v) { field = v; invalidate() }
    var labelStep = 40
        set(v) { field = v; invalidate() }
    var minorStep = 10
        set(v) { field = v; invalidate() }
    var unit = "km/h"
        set(v) { field = v; invalidate() }
    var limit = 0
        set(v) { field = v; invalidate() }

    private var shown = 0f
    private var target = 0f
    private val startAngle = 135f
    private val sweep = 270f
    private val red = Color.parseColor("#FF2323")

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        stroke.style = Paint.Style.STROKE
        text.textAlign = Paint.Align.CENTER
    }

    fun setSpeed(v: Float) {
        target = max(0f, v)
        invalidate()
    }

    private fun px(a: Float, r: Float, cx: Float, v: Float, isX: Boolean): Float {
        val rad = Math.toRadians(a.toDouble())
        return if (isX) cx + (cos(rad) * r).toFloat() else v + (sin(rad) * r).toFloat()
    }

    override fun onDraw(c: Canvas) {
        shown += (target - shown) * 0.16f
        if (abs(target - shown) < 0.05f) shown = target

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f - context.u(4)
        val frac = (shown / maxValue).coerceIn(0f, 1f)
        val ang = startAngle + sweep * frac
        val exceeded = limit > 0 && shown.roundToInt() > limit

        // بدنه
        fill.shader = RadialGradient(cx, cy, r, intArrayOf(0xFF1B1C24.toInt(), 0xFF0A0A0E.toInt()), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, fill)
        fill.shader = null
        stroke.color = 0xFF2E303B.toInt()
        stroke.strokeWidth = context.u(2).toFloat()
        c.drawCircle(cx, cy, r, stroke)

        // ناحیه‌ی قرمز محو داخل کمان
        val rect9 = RectF(cx - r * 0.9f, cy - r * 0.9f, cx + r * 0.9f, cy + r * 0.9f)
        fill.shader = RadialGradient(
            cx, cy, r * 0.9f, intArrayOf(0x00FF2323, 0x00FF2323, 0x6EFF2323),
            floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
        )
        if (frac > 0f) c.drawArc(rect9, startAngle, sweep * frac, true, fill)
        fill.shader = null

        // مسیر کمان و کمان قرمز
        val ra = r * 0.935f
        val arcRect = RectF(cx - ra, cy - ra, cx + ra, cy + ra)
        stroke.strokeWidth = context.u(3).toFloat()
        stroke.color = 0xFF2A2C36.toInt()
        c.drawArc(arcRect, startAngle, sweep, false, stroke)
        stroke.strokeWidth = r * 0.085f
        stroke.color = red
        if (frac > 0f) c.drawArc(arcRect, startAngle, sweep * frac, false, stroke)

        // خط‌های درجه
        var v = 0
        val maxI = maxValue.toInt()
        while (v <= maxI) {
            val a = startAngle + sweep * v / maxValue
            val major = v % labelStep == 0
            val r1 = if (major) r * 0.80f else r * 0.84f
            val r2 = r * 0.885f
            stroke.strokeWidth = context.u(if (major) 2 else 1).toFloat()
            stroke.color = if (major) 0xFFE8EAF0.toInt() else 0xFF6B6F7E.toInt()
            c.drawLine(px(a, r1, cx, cy, true), px(a, r1, cx, cy, false), px(a, r2, cx, cy, true), px(a, r2, cx, cy, false), stroke)
            v += minorStep
        }

        // عددها
        text.typeface = Fonts.forText(context, "0", false)
        text.textSize = r * 0.10f
        text.color = 0xFFE8EAF0.toInt()
        v = 0
        while (v <= maxI) {
            val a = startAngle + sweep * v / maxValue
            val lx = px(a, r * 0.70f, cx, cy, true)
            val ly = px(a, r * 0.70f, cx, cy, false)
            c.drawText("" + v, lx, ly + text.textSize * 0.35f, text)
            v += labelStep
        }

        // عقربه (خط سفید روی کمان)
        stroke.strokeWidth = context.u(3).toFloat()
        stroke.color = Color.WHITE
        c.drawLine(px(ang, r * 0.83f, cx, cy, true), px(ang, r * 0.83f, cx, cy, false), px(ang, r * 0.985f, cx, cy, true), px(ang, r * 0.985f, cx, cy, false), stroke)

        // دایره‌ی وسط
        fill.color = 0xFF13141A.toInt()
        c.drawCircle(cx, cy, r * 0.50f, fill)
        stroke.strokeWidth = context.u(2).toFloat()
        stroke.color = 0xFF262833.toInt()
        c.drawCircle(cx, cy, r * 0.50f, stroke)

        // عدد سرعت و واحد
        text.typeface = Fonts.forText(context, "0", true)
        text.textSize = r * 0.40f
        text.color = if (exceeded) red else Color.WHITE
        c.drawText("" + shown.roundToInt(), cx, cy + text.textSize * 0.28f, text)
        text.typeface = Fonts.forText(context, "0", false)
        text.textSize = r * 0.11f
        text.color = 0xFFA4A8B8.toInt()
        c.drawText(unit, cx, cy + r * 0.36f, text)

        // تابلوی محدودیت
        if (limit > 0) {
            val sw = r * 0.34f
            val sh = r * 0.40f
            val sx = cx
            val sy = cy + r * 0.74f
            val blink = if (exceeded) (0.55f + 0.45f * sin(SystemClock.uptimeMillis() / 160.0).toFloat()) else 1f
            val alpha = (255 * blink).toInt()
            fill.color = Color.argb(alpha, 255, 255, 255)
            c.drawRoundRect(RectF(sx - sw / 2, sy - sh / 2, sx + sw / 2, sy + sh / 2), sw * 0.12f, sw * 0.12f, fill)
            stroke.color = Color.argb(alpha, 20, 20, 20)
            stroke.strokeWidth = context.u(2).toFloat()
            c.drawRoundRect(RectF(sx - sw / 2 + 4, sy - sh / 2 + 4, sx + sw / 2 - 4, sy + sh / 2 - 4), sw * 0.1f, sw * 0.1f, stroke)
            text.color = Color.argb(alpha, 20, 20, 20)
            text.typeface = Fonts.forText(context, "0", true)
            text.textSize = sh * 0.16f
            c.drawText("LIMIT", sx, sy - sh * 0.17f, text)
            text.textSize = sh * 0.42f
            c.drawText("" + limit, sx, sy + sh * 0.27f, text)
        }

        if (abs(target - shown) > 0.05f || exceeded) postInvalidateOnAnimation()
    }
}

// ======================================================================
/** افکت اسپرت: هرچه سرعت بیشتر، لبه‌های صفحه قرمزتر و پرنورتر */
class SportOverlay @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var t = 0f
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        if (t <= 0.01f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val pulse = if (t > 0.85f) 0.88f + 0.12f * sin(SystemClock.uptimeMillis() / 380.0).toFloat() else 1f
        val a = (t * 0.50f * pulse * 255).toInt().coerceIn(0, 255)
        p.shader = RadialGradient(
            w / 2f, h / 2f, max(w, h) * 0.72f,
            intArrayOf(0x00FF1E1E, 0x00FF1E1E, Color.argb(a, 255, 30, 30)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, p)
        val b = (t * 0.40f * pulse * 255).toInt().coerceIn(0, 255)
        p.shader = LinearGradient(
            0f, h, 0f, h * 0.55f, Color.argb(b, 255, 40, 20), 0x00FF2814, Shader.TileMode.CLAMP
        )
        c.drawRect(0f, h * 0.55f, w, h, p)
        p.shader = null
        if (t > 0.85f) postInvalidateOnAnimation()
    }
}

// ======================================================================
/** گوشه‌های گرد برای نقشه: بیرون مستطیل گرد را با رنگ پس‌زمینه می‌پوشاند */
class CornerMask @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var color: Int = 0xFF12141B.toInt()
        set(v) { field = v; invalidate() }
    var radius = 0f
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        path.reset()
        path.fillType = Path.FillType.INVERSE_WINDING
        path.addRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), radius, radius, Path.Direction.CW)
        p.color = color
        c.drawPath(path, p)
    }
}
